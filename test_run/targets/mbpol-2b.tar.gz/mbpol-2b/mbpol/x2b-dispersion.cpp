#include <cmath>

#include "tang-toennies.h"
#include "x2b-dispersion.h"

////////////////////////////////////////////////////////////////////////////////

namespace {

//----------------------------------------------------------------------------//

inline double x68(const double& C6, const double& d6,
                  const double& C8, const double& d8,
                  const double* p1, const double* p2)
{
    const double dx = p1[0] - p2[0];
    const double dy = p1[1] - p2[1];
    const double dz = p1[2] - p2[2];

    const double rsq = dx*dx + dy*dy + dz*dz;
    const double r = std::sqrt(rsq);

    const double tt6 = x2o::tang_toennies(6, d6*r);
    const double tt8 = x2o::tang_toennies(8, d8*r);

    const double inv_rsq = 1.0/rsq;
    const double inv_r6 = inv_rsq*inv_rsq*inv_rsq;

    return - (C6*tt6 + C8*tt8*inv_rsq)*inv_r6;
}

//----------------------------------------------------------------------------//

const double if6 = 1.0/x2o::factorial<6>();
const double if8 = 1.0/x2o::factorial<8>();

//----------------------------------------------------------------------------//

inline double x68(const double& C6, const double& d6,
                  const double& C8, const double& d8,
                  const double* p1, const double* p2,
                        double* g1,       double* g2)
{
    const double dx = p1[0] - p2[0];
    const double dy = p1[1] - p2[1];
    const double dz = p1[2] - p2[2];

    const double rsq = dx*dx + dy*dy + dz*dz;
    const double r = std::sqrt(rsq);

    const double d6r = d6*r;
    const double tt6 = x2o::tang_toennies(6, d6r);

    const double d8r = d8*r;
    const double tt8 = x2o::tang_toennies(8, d8r);

    const double inv_rsq = 1.0/rsq;
    const double inv_r6 = inv_rsq*inv_rsq*inv_rsq;
    const double inv_r8 = inv_r6*inv_rsq;

    const double e6 = C6*tt6*inv_r6;
    const double e8 = C8*tt8*inv_r8;

    const double grd = (6*e6 + 8*e8)*inv_rsq
        - (C6*std::pow(d6, 7)*if6*std::exp(-d6r)
        +  C8*std::pow(d8, 9)*if8*std::exp(-d8r))/r;

    g1[0] += dx*grd;
    g2[0] -= dx*grd;

    g1[1] += dy*grd;
    g2[1] -= dy*grd;

    g1[2] += dz*grd;
    g2[2] -= dz*grd;

    return - (e6 + e8);
}

//----------------------------------------------------------------------------//

} // namespace

////////////////////////////////////////////////////////////////////////////////

namespace x2o {

////////////////////////////////////////////////////////////////////////////////

const double x2b_dispersion::C6_HH =  2.575594070678838e+01; // kcal/mol * A^(-6)
const double x2b_dispersion::C6_OH =  7.761670152098201e+01; // kcal/mol * A^(-6)
const double x2b_dispersion::C6_OO =  2.381872633060112e+02; // kcal/mol * A^(-6)

const double x2b_dispersion::C8_HH = -8.766226951517307e+01; // kcal/mol * A^(-8)
const double x2b_dispersion::C8_OH =  2.480366183720885e+01; // kcal/mol * A^(-8)
const double x2b_dispersion::C8_OO =  4.001889736341507e+03; // kcal/mol * A^(-8)

const double x2b_dispersion::d6_HH =  3.099498541851831e+00; // A^(-1)
const double x2b_dispersion::d6_OH =  7.605816161063661e+00; // A^(-1)
const double x2b_dispersion::d6_OO =  1.883961885664329e+01; // A^(-1)

const double x2b_dispersion::d8_HH =  5.519909031454219e+00; // A^(-1)
const double x2b_dispersion::d8_OH =  7.585009488725105e+00; // A^(-1)
const double x2b_dispersion::d8_OO =  4.468739978471534e+00; // A^(-1)

//----------------------------------------------------------------------------//

double x2b_dispersion::eval(const double* w1, const double* w2)
{
    const double* Oa  = w1;
    const double* Ha1 = w1 + 3;
    const double* Ha2 = w1 + 6;

    const double* Ob  = w2;
    const double* Hb1 = w2 + 3;
    const double* Hb2 = w2 + 6;

    const double HH68 =
        x68(C6_HH, d6_HH, C8_HH, d8_HH, Ha1, Hb1)
      + x68(C6_HH, d6_HH, C8_HH, d8_HH, Ha1, Hb2)
      + x68(C6_HH, d6_HH, C8_HH, d8_HH, Ha2, Hb1)
      + x68(C6_HH, d6_HH, C8_HH, d8_HH, Ha2, Hb2);

    const double OH68 =
        x68(C6_OH, d6_OH, C8_OH, d8_OH, Oa, Hb1)
      + x68(C6_OH, d6_OH, C8_OH, d8_OH, Oa, Hb2)
      + x68(C6_OH, d6_OH, C8_OH, d8_OH, Ob, Ha1)
      + x68(C6_OH, d6_OH, C8_OH, d8_OH, Ob, Ha2);


    const double OO68 =
        x68(C6_OO, d6_OO, C8_OO, d8_OO, Oa, Ob);

    return HH68 + OH68 + OO68;
}

//----------------------------------------------------------------------------//

double x2b_dispersion::eval
    (const double* w1, const double* w2, double* g1, double* g2)
{
    const double* Oa  = w1;
    const double* Ha1 = w1 + 3;
    const double* Ha2 = w1 + 6;

    const double* Ob  = w2;
    const double* Hb1 = w2 + 3;
    const double* Hb2 = w2 + 6;

    double* gOa  = g1;
    double* gHa1 = g1 + 3;
    double* gHa2 = g1 + 6;

    double* gOb  = g2;
    double* gHb1 = g2 + 3;
    double* gHb2 = g2 + 6;

    const double HH68 =
        x68(C6_HH, d6_HH, C8_HH, d8_HH, Ha1, Hb1, gHa1, gHb1)
      + x68(C6_HH, d6_HH, C8_HH, d8_HH, Ha1, Hb2, gHa1, gHb2)
      + x68(C6_HH, d6_HH, C8_HH, d8_HH, Ha2, Hb1, gHa2, gHb1)
      + x68(C6_HH, d6_HH, C8_HH, d8_HH, Ha2, Hb2, gHa2, gHb2);

    const double OH68 =
        x68(C6_OH, d6_OH, C8_OH, d8_OH, Oa, Hb1, gOa, gHb1)
      + x68(C6_OH, d6_OH, C8_OH, d8_OH, Oa, Hb2, gOa, gHb2)
      + x68(C6_OH, d6_OH, C8_OH, d8_OH, Ob, Ha1, gOb, gHa1)
      + x68(C6_OH, d6_OH, C8_OH, d8_OH, Ob, Ha2, gOb, gHa2);


    const double OO68 =
        x68(C6_OO, d6_OO, C8_OO, d8_OO, Oa, Ob, gOa, gOb);

    return HH68 + OH68 + OO68;
}

////////////////////////////////////////////////////////////////////////////////

} // namespace x2o

////////////////////////////////////////////////////////////////////////////////
